package com.example.myapplication;


import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.MqttCallback;

public class MQTTManager {

    private MqttClient mqttClient;
    private String brokerUrl = "tcp://10.106.208.44"; // URL do seu broker MQTT
    private String clientId = "AndroidClient"; // ID do cliente
    private MqttConnectOptions options;

    public MQTTManager() {
        try {
            mqttClient = new MqttClient(brokerUrl, clientId);
            options = new MqttConnectOptions();
            options.setCleanSession(true);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    // Método para conectar ao broker MQTT
    public void connect() {
        try {
            mqttClient.setCallback(new MqttCallback() {
                @Override
                public void connectionLost(Throwable cause) {
                    // Aqui, você pode adicionar lógica para quando a conexão for perdida
                    System.out.println("Conexão perdida!");
                }

                @Override
                public void messageArrived(String topic, MqttMessage message) throws Exception {
                    // Lógica para quando uma mensagem for recebida
                    System.out.println("Mensagem recebida: " + new String(message.getPayload()));
                }

                @Override
                public void deliveryComplete(IMqttDeliveryToken token) {
                    // Lógica para quando a entrega de uma mensagem for completada
                    System.out.println("Mensagem entregue.");
                }
            });

            mqttClient.connect(options);
            System.out.println("Conectado ao Broker MQTT!");
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    // Método para assinar um tópico
    public void subscribe(String topic) {
        try {
            mqttClient.subscribe(topic);
            System.out.println("Assinado ao tópico: " + topic);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    // Método para publicar uma mensagem
    public void publish(String topic, String message) {
        try {
            MqttMessage mqttMessage = new MqttMessage(message.getBytes());
            mqttClient.publish(topic, mqttMessage);
            System.out.println("Mensagem publicada no tópico: " + topic);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    // Método para desconectar
    public void disconnect() {
        try {
            mqttClient.disconnect();
            System.out.println("Desconectado do Broker MQTT");
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }
}

