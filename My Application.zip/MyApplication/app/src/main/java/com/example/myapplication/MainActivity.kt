package com.example.myapplication

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.myapplication.ui.theme.MyApplicationTheme

import org.eclipse.paho.client.mqttv3.*



class MainActivity : ComponentActivity() {

    class MainActivity : ComponentActivity() {

        private lateinit var mqttManager: MQTTManager

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)

            mqttManager = MQTTManager()

            // Conectar ao broker MQTT
            mqttManager.connect()

            // Assinar um tópico
            mqttManager.subscribe("topico/teste")

            // Publicar uma mensagem
            mqttManager.publish("topico/teste", "Olá do Android via MQTT!")

            setContent {
                MyApplicationTheme {
                    // Aqui você pode colocar sua UI Compose
                }
            }
        }

        override fun onDestroy() {
            super.onDestroy()
            mqttManager.disconnect()
        }
    }

}

